# AG PRINTS Printing Module v0.6 — Mobile/Cloud Build

This project includes a GitHub Actions workflow so the debug APK can be built from the cloud without Android Studio on the user's phone.

## Mobile build route
1. Create a GitHub repository from this project.
2. Upload the complete project contents, including `.github/workflows/build-apk.yml`.
3. Open the repository on the phone.
4. Open **Actions** → **Build AG PRINTS APK** → **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run → **Artifacts** → download `AG_PRINTS_Printing_Module_v0.6-debug`.
7. Extract the ZIP and install `app-debug.apk` on the Android phone.

## Laptop route
Open the same project in Android Studio. The GitHub workflow is not required for local Android Studio builds.

## Important
This is a debug/test APK. It is not a Play Store release and does not yet represent verified direct Epson L3250 protocol printing.
