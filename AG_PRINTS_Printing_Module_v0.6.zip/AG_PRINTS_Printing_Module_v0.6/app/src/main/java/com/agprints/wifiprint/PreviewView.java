package com.agprints.wifiprint;

import android.content.*;import android.graphics.*;import android.net.Uri;import android.view.*;import java.util.*;

public class PreviewView extends View {
 Paint p=new Paint(3); ArrayList<Integer> ids; ArrayList<Uri> photos; int per,cols,rows;
 public PreviewView(Context c,ArrayList<Integer> i,int per,ArrayList<Uri> all){super(c);ids=i;this.per=per;photos=new ArrayList<>();for(int x:i)photos.add(all.get(x));if(per==2){cols=1;rows=2;}else if(per==4){cols=2;rows=2;}else if(per==6){cols=2;rows=3;}else if(per==8){cols=2;rows=4;}else if(per==9){cols=3;rows=3;}else{cols=3;rows=4;}setBackgroundColor(Color.LTGRAY);}
 protected void onMeasure(int w,int h){int ww=MeasureSpec.getSize(w);setMeasuredDimension(ww,(int)(ww*1.4142f));}
 protected void onDraw(Canvas c){super.onDraw(c);float pad=10,gap=5,W=getWidth(),H=getHeight();float cw=(W-2*pad-(cols-1)*gap)/cols,ch=(H-2*pad-(rows-1)*gap)/rows;
  p.setStyle(Paint.Style.STROKE);p.setColor(Color.DKGRAY);p.setStrokeWidth(2);c.drawRect(pad,pad,W-pad,H-pad,p);
  p.setStyle(Paint.Style.FILL);for(int k=0;k<per;k++){float l=pad+(k%cols)*(cw+gap),t=pad+(k/cols)*(ch+gap);RectF box=new RectF(l,t,l+cw,t+ch);if(k<photos.size()){try{Bitmap b=BitmapFactory.decodeStream(getContext().getContentResolver().openInputStream(photos.get(k)));float s=Math.min(cw/b.getWidth(),ch/b.getHeight()),bw=b.getWidth()*s,bh=b.getHeight()*s;c.drawBitmap(b,null,new RectF(l+(cw-bw)/2,t+(ch-bh)/2,l+(cw+bw)/2,t+(ch+bh)/2),p);b.recycle();}catch(Exception e){p.setColor(Color.WHITE);c.drawRect(box,p);}}else{p.setColor(Color.WHITE);c.drawRect(box,p);}p.setStyle(Paint.Style.STROKE);p.setColor(0xFF999999);c.drawRect(box,p);p.setStyle(Paint.Style.FILL);}}
}