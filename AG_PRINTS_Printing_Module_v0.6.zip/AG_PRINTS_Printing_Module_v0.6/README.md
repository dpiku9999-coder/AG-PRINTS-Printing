AG PRINTS Printing Module v0.5

Added in v0.5:
- Print-job monitoring using Android Print Framework.
- Photos are marked PRINTED only when Android reports the print job completed; submitting the job alone does not mark them printed.
- Persistent local printed status per photo URI.
- SHOW ONLY UNPRINTED filter.
- Failed print badge (X) for the current app session.
- Epson L3250 test path uses Android's print system, not a proprietary direct Epson protocol.

Epson L3250 compatibility:
- Epson confirms the L3250 has Wi-Fi and Wi-Fi Direct and supports ESC/P-R / ESC/P Raster.
- Epson's Android Print Enabler works with Android's built-in printing system and a wide range of Epson printers.
- For testing, install/enable Epson Print Enabler on the Android phone, connect the phone and L3250 to the same Wi-Fi (or use Wi-Fi Direct), then select the L3250 in the Android print dialog.

Important:
- v0.5 is still a source project/prototype; it is not a signed APK.
- The app does not directly implement Epson's private/proprietary network protocol yet. The next printer-specific step can add a dedicated Epson adapter after real L3250 testing.
