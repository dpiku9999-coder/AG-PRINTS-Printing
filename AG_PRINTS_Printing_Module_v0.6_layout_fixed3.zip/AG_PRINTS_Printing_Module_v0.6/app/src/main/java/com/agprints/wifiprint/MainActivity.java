package com.agprints.wifiprint;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.*;
import android.print.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK=4001;
    GridView grid; TextView status; Spinner layoutSpinner; CheckBox unprintedOnly;
    ArrayList<Uri> photos=new ArrayList<>();
    HashSet<Integer> selected=new HashSet<>();
    HashSet<String> failedUris=new HashSet<>();
    PhotoGridAdapter adapter;
    android.content.SharedPreferences prefs;
    Handler handler=new Handler();
    String activeJobLabel=null;
    ArrayList<String> pendingPrintUris=new ArrayList<>();

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        prefs=getSharedPreferences("print_status",MODE_PRIVATE);
        grid=findViewById(R.id.grid); status=findViewById(R.id.status);
        layoutSpinner=findViewById(R.id.layoutSpinner); unprintedOnly=findViewById(R.id.unprintedOnly);
        String[] a={"1 photo / A4","2 photos / A4","4 photos / A4","6 photos / A4","8 photos / A4","9 photos / A4","12 photos / A4"};
        layoutSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,a));
        adapter=new PhotoGridAdapter(); grid.setAdapter(adapter);
        grid.setOnItemClickListener((p,v,pos,id)->{
            int actual=visibleToActual(pos); if(actual<0)return;
            if(selected.contains(actual))selected.remove(actual); else selected.add(actual);
            adapter.notifyDataSetChanged(); update();
        });
        findViewById(R.id.selectBtn).setOnClickListener(v->pick());
        findViewById(R.id.clearBtn).setOnClickListener(v->{photos.clear();selected.clear();adapter.notifyDataSetChanged();update();});
        findViewById(R.id.previewBtn).setOnClickListener(v->showPreview());
        findViewById(R.id.printBtn).setOnClickListener(v->print());
        layoutSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> p,View v,int x,long id){update();}
            public void onNothingSelected(AdapterView<?> p){}
        });
        unprintedOnly.setOnCheckedChangeListener((button,checked)->{selected.clear();adapter.notifyDataSetChanged();update();});
        update();
    }

    void pick(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK);
    }
    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d); if(r!=PICK||c!=RESULT_OK||d==null)return;
        if(d.getClipData()!=null){for(int x=0;x<d.getClipData().getItemCount();x++)add(d.getClipData().getItemAt(x).getUri());}
        else if(d.getData()!=null)add(d.getData());
        adapter.notifyDataSetChanged(); update();
    }
    void add(Uri u){if(!photos.contains(u))photos.add(u);}
    int per(){return new int[]{1,2,4,6,8,9,12}[layoutSpinner.getSelectedItemPosition()];}
    boolean isPrinted(Uri u){return prefs.getBoolean("printed:"+u.toString(),false);}
    int visibleToActual(int pos){int n=-1;for(int i=0;i<photos.size();i++){if(unprintedOnly.isChecked()&&isPrinted(photos.get(i)))continue;n++;if(n==pos)return i;}return -1;}
    void update(){int visible=0;for(Uri u:photos)if(!unprintedOnly.isChecked()||!isPrinted(u))visible++;status.setText(visible+" photos shown • "+selected.size()+" selected • "+per()+" / A4");}

    void showPreview(){
        if(selected.isEmpty()){toast("Select photos first.");return;}
        PreviewView pv=new PreviewView(this,new ArrayList<>(selected),per(),photos);
        new AlertDialog.Builder(this).setTitle("A4 Visual Preview").setView(pv).setPositiveButton("CLOSE",null).show();
    }

    void print(){
        if(selected.isEmpty()){toast("Select photos first.");return;}
        ArrayList<Uri> out=new ArrayList<>(); pendingPrintUris.clear();
        for(Integer i:selected){out.add(photos.get(i));pendingPrintUris.add(photos.get(i).toString());}
        activeJobLabel="AG PRINTS A4 Photos "+System.currentTimeMillis();
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        PrintAttributes at=new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .setResolution(new PrintAttributes.Resolution("agprints","AG PRINTS",300,300))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
        pm.print(activeJobLabel,new PhotoPrintAdapter(this,out,per()),at);
        handler.postDelayed(this::checkPrintJob,1200);
    }

    void checkPrintJob(){
        if(activeJobLabel==null)return;
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        for(PrintJob j:pm.getPrintJobs()){
            PrintJobInfo info=j.getInfo(); if(!activeJobLabel.equals(info.getLabel()))continue;
            if(j.isCompleted()){
                android.content.SharedPreferences.Editor e=prefs.edit();
                for(String u:pendingPrintUris)e.putBoolean("printed:"+u,true); e.apply();
                toast("Print completed ✓"); activeJobLabel=null; pendingPrintUris.clear(); selected.clear();
                adapter.notifyDataSetChanged(); update(); return;
            }
            if(j.isFailed()){
                failedUris.addAll(pendingPrintUris); toast("Print failed ❌"); activeJobLabel=null; pendingPrintUris.clear(); adapter.notifyDataSetChanged(); return;
            }
            if(j.isCancelled()){
                toast("Print cancelled"); activeJobLabel=null; pendingPrintUris.clear(); return;
            }
        }
        handler.postDelayed(this::checkPrintJob,1200);
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    class PhotoGridAdapter extends BaseAdapter{
        public int getCount(){int n=0;for(Uri u:photos)if(!unprintedOnly.isChecked()||!isPrinted(u))n++;return n;}
        public Object getItem(int p){int a=visibleToActual(p);return a<0?null:photos.get(a);}
        public long getItemId(int p){int a=visibleToActual(p);return a;}
        public View getView(int p,View v,ViewGroup parent){
            int a=visibleToActual(p); FrameLayout box=new FrameLayout(MainActivity.this);
            int w=Math.max(1,parent.getWidth()/3); box.setLayoutParams(new AbsListView.LayoutParams(w,w));
            ImageView im=new ImageView(MainActivity.this); im.setScaleType(ImageView.ScaleType.CENTER_CROP); im.setImageURI(photos.get(a));
            box.addView(im,new FrameLayout.LayoutParams(-1,-1));
            if(isPrinted(photos.get(a))) addBadge(box,"✓",0xCC2E7D32,Gravity.TOP|Gravity.END);
            else if(failedUris.contains(photos.get(a).toString())) addBadge(box,"✕",0xCCB71C1C,Gravity.TOP|Gravity.END);
            if(selected.contains(a)) addBadge(box,"✓",0x990066CC,Gravity.TOP|Gravity.START);
            return box;
        }
        void addBadge(FrameLayout box,String text,int color,int gravity){
            TextView b=new TextView(MainActivity.this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(22); b.setGravity(Gravity.CENTER);
            GradientDrawable bg=new GradientDrawable(); bg.setColor(color); bg.setShape(GradientDrawable.OVAL); b.setBackground(bg);
            FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(50,50,gravity); cp.setMargins(6,6,6,6); box.addView(b,cp);
        }
    }
}
