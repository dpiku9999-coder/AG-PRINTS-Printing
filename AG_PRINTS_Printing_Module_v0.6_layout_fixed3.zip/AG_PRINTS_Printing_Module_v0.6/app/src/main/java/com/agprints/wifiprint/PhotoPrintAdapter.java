package com.agprints.wifiprint;

import android.content.*;import android.graphics.*;import android.graphics.pdf.PdfDocument;import android.media.ExifInterface;import android.net.Uri;import android.os.*;import android.print.*;import java.io.*;import java.util.*;

public class PhotoPrintAdapter extends PrintDocumentAdapter{
 Context ctx;ArrayList<Uri> imgs;int per;public PhotoPrintAdapter(Context c,ArrayList<Uri> i,int p){ctx=c;imgs=i;per=p;}
 public void onLayout(PrintAttributes o,PrintAttributes n,CancellationSignal cs,LayoutResultCallback cb,Bundle e){if(cs.isCanceled()){cb.onLayoutCancelled();return;}cb.onLayoutFinished(new PrintDocumentInfo.Builder("AG_PRINTS_A4.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount((imgs.size()+per-1)/per).build(),true);}
 public void onWrite(PageRange[] pages,ParcelFileDescriptor dest,CancellationSignal cs,WriteResultCallback cb){new Thread(()->{PdfDocument d=new PdfDocument();try{int W=595,H=842,m=18,g=10,cols,rows;if(per==1){cols=1;rows=1;}else if(per==2){cols=1;rows=2;}else if(per==4){cols=2;rows=2;}else if(per==6){cols=2;rows=3;}else if(per==8){cols=2;rows=4;}else if(per==9){cols=3;rows=3;}else{cols=3;rows=4;}float cw=(W-2*m-(cols-1)*g)/(float)cols,ch=(H-2*m-(rows-1)*g)/(float)rows;
 for(int pgno=0;pgno<(imgs.size()+per-1)/per;pgno++){PdfDocument.Page page=d.startPage(new PdfDocument.PageInfo.Builder(W,H,pgno+1).create());Canvas c=page.getCanvas();c.drawColor(Color.WHITE);for(int k=0;k<per;k++){int idx=pgno*per+k;if(idx>=imgs.size())break;int r=k/cols,col=k%cols;RectF box=new RectF(m+col*(cw+g),m+r*(ch+g),m+col*(cw+g)+cw,m+r*(ch+g)+ch);try{Bitmap bitmap=loadOrientedBitmap(imgs.get(idx));if(bitmap!=null){float s=Math.max(box.width()/bitmap.getWidth(),box.height()/bitmap.getHeight()),ww=bitmap.getWidth()*s,hh=bitmap.getHeight()*s;Rect src=new Rect(Math.round((bitmap.getWidth()-box.width()/s)/2f),Math.round((bitmap.getHeight()-box.height()/s)/2f),Math.round((bitmap.getWidth()+box.width()/s)/2f),Math.round((bitmap.getHeight()+box.height()/s)/2f));c.drawBitmap(bitmap,src,box,new Paint(3));bitmap.recycle();}}catch(Exception ignored){}}d.finishPage(page);}
 File f=File.createTempFile("agprints_","pdf",ctx.getCacheDir());try(FileOutputStream fo=new FileOutputStream(f)){d.writeTo(fo);}d.close();try(InputStream in=new FileInputStream(f);OutputStream out=new FileOutputStream(dest.getFileDescriptor())){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))>0)out.write(buffer,0,n);}cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){d.close();cb.onWriteFailed(e.getMessage());}}).start();}
 private Bitmap loadOrientedBitmap(Uri uri) throws IOException {
  BitmapFactory.Options o=new BitmapFactory.Options(); o.inSampleSize=2; Bitmap bitmap;
  try(InputStream in=ctx.getContentResolver().openInputStream(uri)){ bitmap=BitmapFactory.decodeStream(in,null,o); }
  if(bitmap==null)return null;
  int rotation=ExifInterface.ORIENTATION_NORMAL;
  try(InputStream exifIn=ctx.getContentResolver().openInputStream(uri)){ ExifInterface exif=new ExifInterface(exifIn); rotation=exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL); }
  Matrix matrix=new Matrix();
  if(rotation==ExifInterface.ORIENTATION_ROTATE_90)matrix.postRotate(90);
  else if(rotation==ExifInterface.ORIENTATION_ROTATE_180)matrix.postRotate(180);
  else if(rotation==ExifInterface.ORIENTATION_ROTATE_270)matrix.postRotate(270);
  else if(rotation==ExifInterface.ORIENTATION_FLIP_HORIZONTAL)matrix.postScale(-1,1);
  else if(rotation==ExifInterface.ORIENTATION_FLIP_VERTICAL)matrix.postScale(1,-1);
  else if(rotation==ExifInterface.ORIENTATION_TRANSPOSE){matrix.postRotate(90);matrix.postScale(-1,1);}
  else if(rotation==ExifInterface.ORIENTATION_TRANSVERSE){matrix.postRotate(270);matrix.postScale(-1,1);}
  if(!matrix.isIdentity()){Bitmap rotated=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);if(rotated!=bitmap)bitmap.recycle();bitmap=rotated;}
  return bitmap;
 }
}
