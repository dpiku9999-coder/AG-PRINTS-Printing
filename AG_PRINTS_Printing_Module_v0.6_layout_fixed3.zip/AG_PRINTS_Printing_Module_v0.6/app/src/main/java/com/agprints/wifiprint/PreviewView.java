package com.agprints.wifiprint;

import android.content.*;import android.graphics.*;import android.media.ExifInterface;import android.net.Uri;import android.view.*;import java.io.*;import java.util.*;

public class PreviewView extends View {
 Paint p=new Paint(3); ArrayList<Integer> ids; ArrayList<Uri> photos; int per,cols,rows;
 public PreviewView(Context c,ArrayList<Integer> i,int per,ArrayList<Uri> all){super(c);ids=i;this.per=per;photos=new ArrayList<>();for(int x:i)photos.add(all.get(x));if(per==1){cols=1;rows=1;}else if(per==2){cols=1;rows=2;}else if(per==4){cols=2;rows=2;}else if(per==6){cols=2;rows=3;}else if(per==8){cols=2;rows=4;}else if(per==9){cols=3;rows=3;}else{cols=3;rows=4;}setBackgroundColor(Color.WHITE);}
 protected void onMeasure(int w,int h){int ww=MeasureSpec.getSize(w);setMeasuredDimension(ww,(int)(ww*1.4142f));}
 protected void onDraw(Canvas c){super.onDraw(c);float pad=10,gap=5,W=getWidth(),H=getHeight();float cw=(W-2*pad-(cols-1)*gap)/cols,ch=(H-2*pad-(rows-1)*gap)/rows;
  p.setStyle(Paint.Style.STROKE);p.setColor(Color.DKGRAY);p.setStrokeWidth(2);c.drawRect(pad,pad,W-pad,H-pad,p);
  p.setStyle(Paint.Style.FILL);for(int k=0;k<per;k++){float l=pad+(k%cols)*(cw+gap),t=pad+(k/cols)*(ch+gap);RectF box=new RectF(l,t,l+cw,t+ch);if(k<photos.size()){Bitmap b=null;try{b=loadOrientedBitmap(photos.get(k));if(b!=null){float scale=Math.max(cw/b.getWidth(),ch/b.getHeight());float srcW=cw/scale,srcH=ch/scale;Rect src=new Rect(Math.round((b.getWidth()-srcW)/2f),Math.round((b.getHeight()-srcH)/2f),Math.round((b.getWidth()+srcW)/2f),Math.round((b.getHeight()+srcH)/2f));c.drawBitmap(b,src,box,p);}}catch(Exception e){p.setColor(Color.WHITE);c.drawRect(box,p);}finally{if(b!=null)b.recycle();}}else{p.setColor(Color.WHITE);c.drawRect(box,p);}p.setStyle(Paint.Style.STROKE);p.setColor(0xFF999999);c.drawRect(box,p);p.setStyle(Paint.Style.FILL);}}
 private Bitmap loadOrientedBitmap(Uri uri) throws IOException {
  Bitmap bitmap;try(InputStream in=getContext().getContentResolver().openInputStream(uri)){bitmap=BitmapFactory.decodeStream(in);}if(bitmap==null)return null;
  int rotation=ExifInterface.ORIENTATION_NORMAL;try(InputStream exifIn=getContext().getContentResolver().openInputStream(uri)){ExifInterface exif=new ExifInterface(exifIn);rotation=exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);}
  Matrix matrix=new Matrix();if(rotation==ExifInterface.ORIENTATION_ROTATE_90)matrix.postRotate(90);else if(rotation==ExifInterface.ORIENTATION_ROTATE_180)matrix.postRotate(180);else if(rotation==ExifInterface.ORIENTATION_ROTATE_270)matrix.postRotate(270);else if(rotation==ExifInterface.ORIENTATION_FLIP_HORIZONTAL)matrix.postScale(-1,1);else if(rotation==ExifInterface.ORIENTATION_FLIP_VERTICAL)matrix.postScale(1,-1);else if(rotation==ExifInterface.ORIENTATION_TRANSPOSE){matrix.postRotate(90);matrix.postScale(-1,1);}else if(rotation==ExifInterface.ORIENTATION_TRANSVERSE){matrix.postRotate(270);matrix.postScale(-1,1);}
  if(!matrix.isIdentity()){Bitmap rotated=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);if(rotated!=bitmap)bitmap.recycle();bitmap=rotated;}return bitmap;
 }
}
